library(ggplot2)

p <- ggplot(mtcars, aes(mpg, wt)) +
  geom_point() +
  facet_grid(. ~ cyl) +
  theme(panel.spacing = unit(1, "lines"))
p


dat_text <- data.frame(
  label = c("4 cylinders", "6 cylinders", "8 cylinders"),
  cyl   = c(4, 6, 8)
)
p1 <- p + geom_text(
  data    = dat_text,
  mapping = aes(x = -Inf, y = -Inf, label = label),
  hjust   = 1,
  vjust   = -2
)
p1
hjust <- 0.5
vjust <- 0.5
td <- expand.grid(
  hjust=c(0, 0.5, 1),
  vjust=c(0, 0.5, 1)
)
hj <- 0.5
vj <- 1
for(hj in td$hjust){
  for(vj in td$vjust){
    print(hj)
    print(vj)
    p1 <- p + geom_text(data=dat_text, aes(x = -Inf, y = 4, 
                                           label=label,hjust=hj, vjust=vj)) 
    p1
    
  }
}
p1 <- p + geom_text(data=dat_text, aes(x = -Inf, y = -Inf, label=label, angle=20, hjust=hjust, vjust=vjust)) 
p1

ToothGrowth$dose <- as.factor(ToothGrowth$dose)
# Change box plot colors by groups
ggplot(ToothGrowth, aes(x=dose, y=len, fill=supp)) +
  geom_boxplot()
# Change the position
p<-ggplot(ToothGrowth, aes(x=dose, y=len, fill=supp)) +
  geom_boxplot(position=position_dodge(1))
p
unique(ToothGrowth$supp)
dat_text <- data.frame(
  label = c("4 cylinders", "6 cylinders", "8 cylinders"),
  ds   = c(1, 2, 3),
  supp=c('VC','VC','VC')  
)
View(ToothGrowth)
  
p1 <- p + annotate("text", x = c(0.5, 1, 2), y = 35,
          label = c("label 1", "label 2","label 3") , color="orange",
          size=7 , angle=45, fontface="bold")
p1
p1 <- p + geom_text(data=dat_text, aes(x = ds, y = 35, label=label,
                                       hjust=0.5)) #, hjust=hjust, vjust=vjust
p1
dat_text <- data.frame(
  label = c("4 cylinders", "6 cylinders", "8 cylinders"),
  cyl   = c(4, 6, 8),
  x     = c(20, 27.5, 25),
  y     = c(4, 4, 4.5)
)

p1 <- p + geom_text(
  data    = dat_text,
  mapping = aes(x = x, y = y, label = label)
)
p1



library(dplyr)
library(ggplot2)
ToothGrowth <- ToothGrowth %>%
  dplyr::mutate(dose_desc=case_when(
    dose == 0.5 ~ "aaa",
    dose == 1 ~ "bbb",
    dose == 2 ~ "ccc",
    TRUE ~ 'other'
  ))
ToothGrowth$dose_desc <- as.factor(ToothGrowth$dose_desc)
t1 <- ToothGrowth
t1$series <- 'Pt1'
t2 <- ToothGrowth
t2$series <- 'Pt2'
t3 <- ToothGrowth
t3$series <- 'Pt3'


t <- dplyr::bind_rows(as.data.frame(t1),as.data.frame(t2),as.data.frame(t3))

# Change box plot colors by groups
# Change the position
class(t)
dim(t)

p<-ggplot(t, aes(x=dose_desc, y=len, fill=supp)) +
  geom_boxplot(position=position_dodge(1)) + 
  facet_grid(. ~ series) +
  theme(panel.spacing = unit(1, "lines"))
p

# p<-ggplot(ToothGrowth, aes(x=dose, y=len, fill=supp)) +
#   geom_boxplot(position=position_dodge(1))
# p

dat_text1 <- data.frame(
  label = c("*", " ","**"),
  ds   = c('aaa', 'bbb', 'ccc'),
  supp=c('VC','VC','VC')  
)

dat_text <- data.frame(
  label = c("*", " ","**"),
  ds   = c('aaa', 'bbb', 'ccc'),
  supp=c('VC','VC','VC')
  # series=c('Pt1','Pt2','Pt3')
)

dat_text2 <- data.frame(
  label = c("***", "*","*"),
  ds   = c('aaa', 'bbb', 'ccc'),
  supp=c('VC','VC','VC')
  # series=c('Pt1','Pt2','Pt3')
)

dat_text3 <- data.frame(
  label = c("**", "***",""),
  ds   = c('aaa', 'bbb', 'ccc'),
  supp=c('VC','VC','VC')
  # series=c('Pt1','Pt2','Pt3')
)

# dat_text1 <- dat_text
dat_text1$series <- 'Pt1'
# dat_text2 <- dat_text2
dat_text2$series <- 'Pt2'
# dat_text3 <- dat_text3
dat_text3$series <- 'Pt3'
anno <- dplyr::bind_rows(dat_text1,dat_text2,dat_text3)
# View(ToothGrowth)

# p1 <- p + annotate("text", x = c(1, 2, 3), y = 35,
#                    label = c("*", " ","**") , color="black",
#                    size=7 , fontface="bold") #angle=45, 
# p1
# p1 <- p + geom_text(data=dat_text, aes(x = ds, y = 35, label=label,
#                                        hjust=0.5)) #, hjust=hjust, vjust=vjust
# p1

p1 <- p + geom_text(data=anno, aes(x = ds, y = 35, label=label,
                                       hjust=0.5)) #, hjust=hjust, vjust=vjust
p1


p.values <- c(9.5e-15, 0.02)
signif <- stats::symnum(p.values, corr = FALSE, na = FALSE, 
                        cutpoints = c(0, 0.001, 0.01, 0.05, 0.1, 1), 
                        symbols = c("***", "**", "*", ".", " "))
# stat_df: ks statistical tests, and metasample info
# de_df: df of logFC values
get_boxplot_ksStat <- function(stat_df, de_df, save_dir, datatag='allSeries'){
  # library(dplyr)
  # library(ggplot2)
  yl <- c(-3.5, 3.5)
  de_df <- de_df %>%
    dplyr::mutate(logFC=case_when(
      logFC < yl[1] ~ yl[1],
      logFC > yl[2] ~ yl[2],
      TRUE ~ logFC
  ))
  de_df <- de_df %>%
    dplyr::mutate(classified_gene=case_when(
      classified_gene =='in_cis' ~ "In cis",
      classified_gene =='in_trans' ~ "In trans",
      TRUE ~ classified_gene
    ))
  GT <- c("chocolate", "blue2")
  names(GT) <- c("In cis", "In trans")
  stat_df$labels_detailed <- gsub(' vs. ','\nvs. ',stat_df$labels_detailed)
  meta_info <- stat_df %>%
    select(file_header,labels_detailed, ks_stat, series, order)
  de_df <- de_df %>%
    left_join(meta_info, by='file_header') %>%
    arrange(order)
  
  # de_df$labels_detailed <- gsub(' vs. ','\nvs. ',de_df$labels_detailed)
  de_df$labels_detailed <- factor(de_df$labels_detailed, levels=unique(de_df$labels_detailed))
  p <- ggplot(de_df, aes(x=labels_detailed, y=logFC, fill=classified_gene)) +
    geom_boxplot(position=position_dodge(1), outlier.size = 0.02) + 
    scale_fill_manual(values = GT, name='Gene type') +
    facet_grid(. ~ series, scales="free", space='free') +
    theme(panel.spacing = unit(1, "lines"),
          axis.text.x = element_text(color="black", size=9, hjust = 0.5, angle = 90)) + 
    ylim(yl[1],yl[2]+0.3) + 
    labs(x=NULL,y='log2 FC',title='Degree of gene type expression')
  # p
  ## converting ks signf to star symbol
  signif_level <- stats::symnum(stat_df$ks_stat, corr = FALSE, na = FALSE, 
                          cutpoints = c(0, 0.001, 0.01, 0.05, 0.1, 1), 
                          symbols = c("***", "**", "*", ".", " "))
  stat_df$signif_level <- as.character(signif_level)
  stat_df$classified_gene <- 'in_cis'
  
  p1 <- p + geom_text(data=stat_df, aes(x = labels_detailed, y = yl[2]+0.2, label=signif_level,
                                    ), hjust=0.5, size=4) #, hjust=hjust, vjust=vjust
  # p1
  
  my_font <- "Helvetica"
  thesis_theme <- ggplot2::theme(
    text = element_text(color="black",size = 8, hjust = 0.5, family=my_font),
    axis.title.x = element_text(color="black",size=8, hjust = 0.5, family=my_font),  
    axis.title.y = element_text(color="black",size=8, hjust = 0.5, family=my_font),
    axis.text.x = element_text(color="black",size=6, hjust = 0.5, family=my_font, angle = 90),
    # axis.text.x = element_blank(),
    axis.text.y = element_text(color="black",size=7, hjust = 0.5, family=my_font),
    plot.title = element_text(color="black",size=10, face="bold", hjust=0, family=my_font),
    legend.title=element_text(color="black",size=7, hjust = 0.5, family=my_font), 
    legend.text=element_text(color="black",size=7, hjust = 0.5, family=my_font),
    strip.text.x = element_text(color="black",size=9, family=my_font),
    strip.text.y = element_text(color="black",size=9, family=my_font),
    legend.spacing.x = unit(0.1, 'mm'),
    legend.spacing.y = unit(0.1, 'mm'),
    legend.key.height=unit(1,"line"),
    legend.position = 'bottom',
    panel.grid.major = element_blank(), panel.grid.minor = element_blank()
  )
  p1 <- p1 + thesis_theme
  png(paste0(save_dir,datatag,'_ks_test.png'), height = 2*500, width=2*1000,res = 2*72)
  print(p1)
  dev.off()
  
  return(p1)
}