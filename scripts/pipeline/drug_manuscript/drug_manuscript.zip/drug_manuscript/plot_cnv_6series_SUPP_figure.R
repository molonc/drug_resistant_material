source('/home/htran/Projects/farhia_project/rnaseq/pipeline/drug_manuscript/cnv_viz_utils.R')

clones <- c('R','H')
# clones <- c('A','H')
save_dir <- '/home/htran/storage/datasets/drug_resistance/rna_results/manuscript/dlp_cnv/'
base_name <- 'SA609'
df_cnv_fn <- paste0(save_dir,base_name, '_cnv_mat.csv')


input_dir <- '/home/htran/storage/datasets/drug_resistance/dlp_results/SA609/'
# input_dir <- '/home/htran/Projects/farhia_project/drug_resistant_material/materials/dlp_cnv/Fig6_Mirela_cnv/'
df_cnv_fn <- paste0(input_dir, 'total_merged_filtered_states_original.csv') #

base_dir <- '/home/htran/storage/datasets/drug_resistance/dlp_results/'
input_dir <- '/home/htran/storage/datasets/drug_resistance/rna_results/manuscript/cell_clones/'
save_dir <- paste0(input_dir, 'fig_medianCNV/')





datatag <- 'SA501'
copynumber_fn <- paste0(base_dir,'SA501_v2/total_merged_filtered_states.csv')
cellclone_fn <- paste0(input_dir, datatag, '_cell_clones.csv')
df_cnv <- get_median_genotype_v3(copynumber_fn, datatag, save_dir,
                                 cellclone_fn, library_grouping_fn=NULL) 
dim(df_cnv)
res_501 <- plot_CNV_profile(df_cnv, clones= levels(df_cnv$clone),plttitle='Pt1')
res_501$cnv_plot
res_501$plg
dev.off()




datatag <- 'SA530'
copynumber_fn <- paste0(base_dir,'SA530_v2/total_merged_filtered_states.csv')
cellclone_fn <- paste0(input_dir, datatag, '_cell_clones.csv')
df_cnv <- get_median_genotype_v3(copynumber_fn, datatag, save_dir,
                                 cellclone_fn, library_grouping_fn=NULL) 
dim(df_cnv)
res_530 <- plot_CNV_profile(df_cnv, clones= levels(df_cnv$clone),plttitle='Pt2')
res_530$cnv_plot
dev.off()


datatag <- 'SA604'
copynumber_fn <- paste0(base_dir,'SA604_v2/total_merged_filtered_states.csv')
cellclone_fn <- paste0(input_dir, datatag, '_cell_clones.csv')
df_cnv <- get_median_genotype_v3(copynumber_fn, datatag, save_dir,
                                 cellclone_fn, library_grouping_fn=NULL) 
dim(df_cnv)
res_604 <- plot_CNV_profile(df_cnv, clones= levels(df_cnv$clone),plttitle='Pt3')
res_604$cnv_plot
res_604$plg
dev.off()


datatag <- 'SA609'
copynumber_fn <- paste0(base_dir,datatag,'/total_merged_filtered_states_original.csv')
cellclone_fn <- paste0(input_dir, datatag, '_cell_clones.csv')
df_cnv <- get_median_genotype_v3(copynumber_fn, datatag, save_dir,
                                 cellclone_fn, library_grouping_fn=NULL) 
dim(df_cnv)
res_609 <- plot_CNV_profile(df_cnv, clones= levels(df_cnv$clone),plttitle='Pt4')
res_609$cnv_plot
res_609$plg


datatag <- 'SA535'
copynumber_fn <- paste0(base_dir,'SA535/SA535_fitness/total_merged_filtered_states.csv')
cellclone_fn <- paste0(input_dir, datatag, '_cell_clones.csv')
df_cnv <- get_median_genotype_v3(copynumber_fn, datatag, save_dir,
                                 cellclone_fn, library_grouping_fn=NULL) 
dim(df_cnv)
colnames(df_cnv)
unique(df_cnv$clone)
res_535 <- plot_CNV_profile(df_cnv, clones= levels(df_cnv$clone),plttitle='Pt5')
res_535$cnv_plot
dev.off()

datatag <- 'SA1035'
copynumber_fn <- paste0(base_dir,'SA1035_new_encode/SA1035_Tyler_v2/total_merged_filtered_states.csv')
cellclone_fn <- paste0(input_dir, datatag, '_cell_clones.csv')
df_cnv <- get_median_genotype_v3(copynumber_fn, datatag, save_dir,
                                 cellclone_fn, library_grouping_fn=NULL) 
dim(df_cnv)
res_1035 <- plot_CNV_profile(df_cnv, clones= levels(df_cnv$clone),plttitle='Pt6')
res_1035$cnv_plot
dev.off()

# rel_heights = c(4.5,4,
#                 4.5,10.5,
#                 12.5,11.5)
plt_total <- cowplot::plot_grid(res_501$cnv_plot, res_609$cnv_plot, 
                                res_530$cnv_plot, res_535$cnv_plot, 
                                res_604$cnv_plot, res_1035$cnv_plot,
                                # align = 'v',
                                ncol = 2
                                ) + #labels = c('SA501','SA530','SA604','SA609','SA535','SA1035')
             theme(plot.background = element_rect(fill = "white", colour = "white"))

plt_total2 <- cowplot::plot_grid(plt_total, res_501$plg, ncol = 1, rel_heights=c(15,1)) + theme(plot.background = element_rect(fill = "white", colour = "white"))

plt_total
ggsave(paste0(save_dir,"Fig2_DLPtree_clonealign_correlation.pdf"),
       plot = plt_total2,
       height = 12,
       width = 7.5,
       useDingbats=F,
       dpi = 150
)

ggsave(paste0(save_dir,"Fig_SUPP2_segmentCNV.png"),
       plot = plt_total2,
       height = 8,
       width = 9,
       type = "cairo-png",
       dpi=300
)








results_dir <- '/home/htran/storage/datasets/drug_resistance/dlp_results/SA501_v2/'
datatag <- 'SA501'
res_501 <- get_median_genotype_v2(datatag, results_dir, copynumber_fn=NULL, cellclone_fn=NULL,
                                  calcul_distance=T, distance_type='Manhattan')

saveRDS(res_501, paste0(save_dir, datatag, '_results_CNA_distance.rds'))
min(res_501$out_mtx$CNA_Distance)
max(res_501$out_mtx$CNA_Distance)
results_dir <- '/home/htran/storage/datasets/drug_resistance/dlp_results/SA604_v2/'
datatag <- 'SA604'
res_SA604 <- get_median_genotype_v2(datatag, results_dir, copynumber_fn=NULL, cellclone_fn=NULL,
                                    calcul_distance=T, distance_type='Manhattan')
saveRDS(res_SA604, paste0(save_dir, datatag, '_results_CNA_distance.rds'))
min(res_SA604$out_mtx$CNA_Distance)
max(res_SA604$out_mtx$CNA_Distance)

results_dir <- '/home/htran/storage/datasets/drug_resistance/dlp_results/SA530_v2/'
datatag <- 'SA530'
res_SA530 <- get_median_genotype_v2(datatag, results_dir, copynumber_fn=NULL, cellclone_fn=NULL,
                                    calcul_distance=T, distance_type='Manhattan')
saveRDS(res_SA530, paste0(save_dir, datatag, '_results_CNA_distance.rds'))



results_dir <- '/home/htran/storage/datasets/drug_resistance/dlp_results/SA1035_new_encode/SA1035_Tyler_v2/'
datatag <- 'SA1035'
res_SA1035 <- get_median_genotype_v2(datatag, results_dir, copynumber_fn=NULL, cellclone_fn=NULL,
                                     calcul_distance=T, distance_type='Manhattan')
saveRDS(res_SA1035, paste0(save_dir, datatag, '_results_CNA_distance.rds'))
min(res_SA1035$out_mtx$CNA_Distance)
max(res_SA1035$out_mtx$CNA_Distance)


# chrs <- data.table::fread('/home/htran/storage/datasets/drug_resistance/dlp_results/SA1035_new_encode/SA1035_Tyler_v2/CN_profile/median_cnv.csv')
# length(unique(chrs$chr_desc))
results_dir <- '/home/htran/storage/datasets/drug_resistance/dlp_results/SA609/'
datatag <- 'SA609'
base_dir <- '/home/htran/storage/raw_DLP/drug_resistance_DLP/SA609/reads_clones/'
df <- data.table::fread(paste0(base_dir,'SA609_cisplatin_segments_total.csv')) #filtered_reads_total.csv.gz
dim(df)
head(df)
df$chr_desc <- paste0(df$chr,'_',df$start,'_',df$end)
df$median_cn <- df$state
df$clone_id <- gsub('clone_','',df$clone_id)
res_SA609 <- get_median_genotype_v2(datatag, results_dir, copynumber_fn=NULL, cellclone_fn=NULL,
                                    calcul_distance=T, distance_type='Manhattan')
saveRDS(res_SA609, paste0(save_dir, datatag, '_results_CNA_distance.rds'))
res_SA609 <- res
min(res_SA609$out_mtx$CNA_Distance)
max(res_SA609$out_mtx$CNA_Distance)


results_dir <- '/home/htran/storage/datasets/drug_resistance/dlp_results/SA535/SA535_fitness/'
datatag <- 'SA535'
res_SA535 <- get_median_genotype_v2(datatag, results_dir, copynumber_fn=NULL, cellclone_fn=NULL,
                                    calcul_distance=T, distance_type='Manhattan')
saveRDS(res_SA535, paste0(save_dir, datatag, '_results_CNA_distance.rds'))
